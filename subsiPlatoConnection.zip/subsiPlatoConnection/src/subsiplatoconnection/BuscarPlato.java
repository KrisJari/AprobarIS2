/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package subsiplatoconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author CristinaLaCampeona
 */
public class BuscarPlato extends javax.swing.JInternalFrame {

    /**
     * Creates new form BuscarPlato
     */
    public BuscarPlato() {
        initComponents();
    }

 
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        alerg = new javax.swing.JTextField();
        precio = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        ofert = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        ing = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        ver = new javax.swing.JButton();

        jLabel4.setText("jLabel4");

        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });

        jLabel2.setText("precio");

        jButton1.setText("Buscar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Eliminar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Modificar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null}
            },
            new String [] {
                "id", "NombrePlato", "alergenos", "precio", "oferta", "ingredientes"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabla);

        jLabel6.setText("id:");

        jLabel7.setText("nombrePlato:");

        jLabel8.setText("alergenos");

        jLabel9.setText("oferta");

        jLabel10.setText("ingredientes:");

        jLabel1.setFont(new java.awt.Font("Notram", 0, 12)); // NOI18N
        jLabel1.setText("Buscar Plato");

        ver.setText("Vista");
        ver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(102, 102, 102)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(9, 9, 9)
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(alerg, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(precio, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ofert, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addGap(29, 29, 29)
                                .addComponent(ing, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(213, 213, 213))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(jButton1)
                        .addGap(53, 53, 53)
                        .addComponent(jButton3)
                        .addGap(51, 51, 51)
                        .addComponent(jButton2)
                        .addGap(40, 40, 40)
                        .addComponent(ver))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(287, 287, 287)
                        .addComponent(jLabel1)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(212, 212, 212)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(46, 46, 46)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(alerg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(precio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel2)
                            .addComponent(jLabel9)
                            .addComponent(ofert, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(ing, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(ver))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
       
    }//GEN-LAST:event_idActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // boton buscar buscar por id y te sale todos los campos rellenados 
    
         try {
            
            PreparedStatement ps;
           Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sistemasaplato","root","");
           ps=con.prepareStatement("SELECT * FROM plato WHERE id =?");
            
           ps.setString(1,id.getText());
         
          ResultSet rs=ps.executeQuery();
          
           
           //int res=ps.executeUpdate();
           
           if(rs.next())
           {
              id.setText(rs.getString("id"));
              nombre.setText(rs.getString("nombrePlato"));
              alerg.setText(rs.getString("alergenos"));
              precio.setText(rs.getString("precio"));
              ofert.setText(rs.getString("oferta"));
              ing.setText(rs.getString("ingredientes"));
              //LimpiarCajas();
           }
           else
           {
                JOptionPane.showMessageDialog(null,"Error de busqueda");
                LimpiarCajas();
           }
           con.close();
           
          
        } catch (SQLException ex) {
            Logger.getLogger(PantallaConsultar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // boton modificar despues de buscar al rellenarse los campos puedes mpdificarlos
        
          try {
            
            PreparedStatement ps;
           Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sistemasaplato","root","");
           ps=con.prepareStatement("UPDATE plato SET id =?,nombrePlato =?,alergenos=?,precio =?,oferta =?,ingredientes=? WHERE id =?");
            
           ps.setString(1,id.getText());
           ps.setString(2,nombre.getText());
           ps.setString(3,alerg.getText());
           ps.setString(4,precio.getText());
           ps.setString(5,ofert.getText());
           ps.setString(6,ing.getText());
           ps.setString(7, id.getText());
           
           
           int res=ps.executeUpdate();
           
           if(res>0)
           {
              JOptionPane.showMessageDialog(null,"Plato modificado");
              LimpiarCajas();
           }
           else
           {
                JOptionPane.showMessageDialog(null,"Error de modificado");
                LimpiarCajas();
           }
           con.close();
           
        } catch (SQLException ex) {
            Logger.getLogger(PantallaConsultar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // boton eliminar con el id elimina la fila entera 
         try {
            
            PreparedStatement ps;
           Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sistemasaplato","root","");
           ps=con.prepareStatement("DELETE FROM plato WHERE id=?");
            
           ps.setInt(1,Integer.parseInt(id.getText()));
          
           
           int res=ps.executeUpdate();
           
           if(res>0)
           {
              JOptionPane.showMessageDialog(null,"Plato eliminado");
              LimpiarCajas();
           }
           else
           {
                JOptionPane.showMessageDialog(null,"Error de eliminacion");
                LimpiarCajas();
           }
           con.close();
           
        } catch (SQLException ex) {
            Logger.getLogger(PantallaConsultar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void verActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verActionPerformed
        // boton vista se ve todo lo que hay en la base de datos 
        
            try {
            
            DefaultTableModel modelo=(DefaultTableModel)tabla.getModel();
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sistemasaplato","root","");
            Statement stmt=con.createStatement();
            ResultSet rs= stmt.executeQuery("SELECT * FROM plato");
          
           
              while(rs.next())
            {
              
                String[] fila={rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)};
               modelo.addRow(fila);
               
          
            }
   
          
        } catch (SQLException ex) {
            Logger.getLogger(PantallaConsultar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }//GEN-LAST:event_verActionPerformed

    private void LimpiarCajas() {
         id.setText(null);
       nombre.setText(null);
       alerg.setText(null);
       precio.setText(null);
       ofert.setText(null);
       //ing.setSelectedIndex(0);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField alerg;
    private javax.swing.JTextField id;
    private javax.swing.JTextField ing;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField nombre;
    private javax.swing.JTextField ofert;
    private javax.swing.JTextField precio;
    private javax.swing.JTable tabla;
    private javax.swing.JButton ver;
    // End of variables declaration//GEN-END:variables
}
